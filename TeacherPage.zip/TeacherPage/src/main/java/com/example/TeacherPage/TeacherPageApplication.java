package com.example.TeacherPage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeacherPageApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeacherPageApplication.class, args);
	}

}
