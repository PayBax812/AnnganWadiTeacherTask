package com.example.TeacherPage.repository;

import com.example.TeacherPage.model.teacher;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TeacherRepository extends JpaRepository<teacher, Long> {
}
