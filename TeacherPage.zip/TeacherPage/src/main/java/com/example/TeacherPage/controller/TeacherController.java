package com.example.TeacherPage.controller;

import com.example.TeacherPage.model.teacher;
import com.example.TeacherPage.service.TeacherService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/teachers")
public class TeacherController {

    private final TeacherService teacherService;

    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @GetMapping("/")
    public String homePage() {
        return "index";
    }

    @GetMapping("/add")
    public String showAddTeacherForm(Model model) {
        model.addAttribute("teacher", new teacher());
        return "add-teacher";
    }

    @PostMapping("/add")
    public String addTeacher(@ModelAttribute("teacher") teacher teachernew, Model model) {
        teacherService.saveTeacher(teachernew);
        model.addAttribute("message", "New Teacher Added Successfully!");
        return "redirect:/teachers/list";  // ✅ Redirect to list page after saving
    }


    @GetMapping("/list")
    public String listTeachers(Model model) {
        // ✅ Fetch from DB instead of hardcoded list
        List<teacher> teachers = teacherService.getAllTeachers();
        model.addAttribute("teachers", teachers);
        return "list-teachers";
    }
}

